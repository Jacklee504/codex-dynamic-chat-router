# Phase 2 — Routing Intelligence, Model Selection, and Fanout

## Objective

Build the deterministic routing layer on top of the Phase 1 provider runtime.

At the end of this phase the orchestrator must be able to:

- classify a task into a structured profile
- select a suitable provider/model
- select reasoning effort independently from model selection
- respect risk, locality, privacy, and model-family diversity
- execute a single routed task
- fan the same read-only task out to multiple independent model families
- explain why each selection was made

Do not add OpenRouter or cross-provider write access yet.

---

## Required prerequisite

Phase 1 must be complete and passing before this phase starts.

Do not rewrite provider adapters unless required by a failing interface or missing metadata.

---

## Add routing modules

Create:

```text
packages/orchestrator/src/routing/
├── classifier.ts
├── selector.ts
├── effort.ts
├── diversity.ts
├── explain.ts
└── fallback.ts
```

Create:

```text
packages/orchestrator/src/strategies/
├── single.ts
└── fanout.ts
```

---

## Task profile

Extend shared types with a task profile.

Use a structure equivalent to:

```ts
export type Complexity = "trivial" | "normal" | "difficult" | "extreme";
export type RiskLevel = "low" | "medium" | "high";
export type DiversityLevel = "none" | "low" | "medium" | "high";

export interface TaskProfile {
  role: WorkerRole;
  complexity: Complexity;
  risk: RiskLevel;
  preferLocal: boolean;
  requireLocal: boolean;
  privacySensitive: boolean;
  diversity: DiversityLevel;
  contextRequirement?: "small" | "medium" | "large" | "huge";
  requiresTools: boolean;
}
```

The router must not select a model before a profile exists.

---

## Classification approach

Do not use a paid model just to classify tasks in this phase.

Start deterministic and explainable.

Classification inputs can include:

- requested role
- explicit user flags
- number of files/paths when known
- destructive/production/financial/security keywords
- whether root cause is known
- whether implementation vs review is requested
- whether local-only/privacy is requested

Allow CLI flags to override inferred values.

Example:

```bash
dtr route \
  --role debugger \
  --risk high \
  --complexity difficult \
  --diversity medium \
  --prompt "Find why valid signals never reach order submission"
```

Do not overfit classification heuristics to trading systems specifically.

---

## Model registry

Expand `config/models.yaml` into the main model registry.

Each model entry should support:

```yaml
provider: codex
family: openai
model: gpt-5.6-terra
enabled: true
local: false
roles:
  architect: 8
  implementer: 8
  debugger: 9
  reviewer: 10
  researcher: 8
  test: 9
  log-analysis: 8
efforts:
  - low
  - medium
  - high
  - xhigh
default_effort: high
```

Also add optional capability metadata:

```yaml
capabilities:
  tools: true
  vision: false
  huge_context: false
  write_safe: false
```

Do not encode an absolute global model ranking.

A model may be strongest for one role and weaker for another.

Document all initial numeric scores as manually chosen routing priors.

---

## Model selection

Implement an explainable scoring function.

Start simple.

Example concept:

```ts
score = roleScore

if (task.preferLocal && model.local) score += localBonus
if (task.requireLocal && !model.local) reject
if (task.requiresTools && !model.capabilities.tools) reject
if (task.complexity === "extreme" && roleScore < minimum) reject
if (task.risk === "high" && roleScore < riskMinimum) reject
```

Selection must first filter ineligible models, then score eligible models.

Every selection result must include a machine-readable explanation:

```json
{
  "selected": "codex-terra",
  "score": 14,
  "reasons": [
    "reviewer role score=10",
    "high-risk review bonus=2",
    "independent family required=2"
  ],
  "rejected": {
    "qwen-local": ["below minimum reviewer score for high-risk task"]
  }
}
```

---

## Reasoning effort selection

Reasoning effort must be selected separately from model choice.

Use `config/routing-policy.yaml`.

Example policy:

```yaml
effort:
  trivial:
    default: low
  normal:
    default: medium
  difficult:
    default: high
  extreme:
    default: xhigh

risk_overrides:
  financial:
    minimum: high
  security:
    minimum: high
  destructive:
    minimum: high
  production:
    minimum: high
```

If the selected model does not support the desired effort:

- map to the nearest supported effort according to an explicit rule
- record requested vs effective effort
- never silently pretend unsupported effort was used

---

## Diversity routing

Implement model-family diversity as a first-class concept.

Families are independent of provider IDs.

Examples:

```text
anthropic
openai
openai-open
qwen
google
mistral
deepseek
```

Initial rules:

```yaml
diversity:
  none:
    minimum_families: 1
  low:
    minimum_families: 1
  medium:
    minimum_families: 2
  high:
    minimum_families: 2
    require_independent_review: true
```

If a task requires two families and only one is available, return a clear degraded-routing result rather than faking diversity.

---

## Single strategy

Implement `strategies/single.ts`.

Flow:

```text
request
→ task profile
→ eligibility filter
→ model scoring
→ model selection
→ effort selection
→ provider invocation
→ telemetry
→ result
```

Expose through CLI:

```bash
dtr route --prompt "..." --role debugger
```

Output should include:

- selected provider/model
- effective effort
- why it was selected
- worker result
- run ID

---

## Fanout strategy

Implement `strategies/fanout.ts` for read-only independent analysis.

Purpose:

Send the same bounded task to multiple models from independent families.

Example:

```text
"Why are orders not being submitted?"
        ├── Claude
        ├── Codex
        └── Qwen
```

Requirements:

- all fanout workers are read-only
- prefer distinct families
- run independent workers concurrently when safe
- do not share sibling outputs between workers
- return results separately
- do not ask one worker to summarize other workers
- preserve the current compact worker contract

CLI:

```bash
dtr fanout \
  --families 2 \
  --role debugger \
  --risk high \
  --prompt "..."
```

Do not implement final synthesis using another model in this phase. The caller/lead owns integration.

---

## Fallback policy

Implement deterministic fallbacks.

Examples:

```text
selected Claude unavailable
→ choose next eligible model
→ log requested + fallback

requested high effort unsupported
→ choose nearest supported effort
→ log mapping

local-only task but Ollama unavailable
→ fail closed

privacy-sensitive task and only disallowed remote candidates exist
→ fail closed
```

Never silently violate:

- local-only
- read-only
- privacy
- model-family diversity requirements

---

## New CLI commands

Add:

```text
dtr select
dtr route
dtr fanout
```

### `dtr select`

Dry-run selection only.

Example:

```bash
dtr select \
  --role reviewer \
  --complexity difficult \
  --risk high \
  --diversity medium
```

Must not invoke a model.

### `dtr route`

Select and run one worker.

### `dtr fanout`

Select and run multiple independent workers.

---

## Documentation

Create/update:

```text
core/model-selection.md
core/task-taxonomy.md
core/safety-policy.md
docs/model-selection.md
docs/routing.md
```

`core/` should remain concise normative policy.

`docs/` can contain detailed explanation and examples.

Document:

- task profile fields
- role definitions
- model scoring
- effort routing
- diversity routing
- fallback behavior
- why priors are not benchmark claims

---

## Tests

Add tests for at least:

- best-role model selection
- local preference
- local requirement
- unsupported effort mapping
- high-risk minimum effort
- model-family diversity
- degraded diversity behavior
- unavailable provider fallback
- privacy fail-closed behavior
- single execution selection metadata
- fanout chooses independent families
- fanout does not send sibling outputs to workers

Include table-driven tests for selection policy.

---

## Acceptance scenarios

Add/update `core/acceptance-scenarios.md` with examples including:

### Straightforward implementation

Expected:

- worker-tier model
- medium effort
- one family

### Difficult unknown bug

Expected:

- stronger debugger model
- high effort
- medium/high diversity if requested

### High-risk financial review

Expected:

- high minimum effort
- strong reviewer
- independent family review when available

### Local-only log analysis

Expected:

- local Ollama model only
- no remote fallback

### Provider unavailable

Expected:

- explicit fallback or explicit failure according to policy

---

## Acceptance criteria

Phase 2 is complete only when:

- Phase 1 still passes
- `dtr select` deterministically explains model choice
- model and effort are chosen independently
- high-risk rules are enforced
- local-only/privacy constraints fail closed
- `dtr route` automatically selects and invokes one worker
- `dtr fanout` invokes multiple independent families where available
- all fanout workers remain read-only
- fallbacks are explicit and logged
- tests cover selection, diversity, effort, and failure cases

---

## Do not implement yet

Do not add:

- OpenRouter
- Gemini
- cross-provider writing
- worktrees
- autonomous score learning
- automatic model synthesis
- UI/dashboard

Those belong in later phases.

---

## Final Codex report

Return:

1. changed files
2. new routing algorithm summary
3. default model priors used
4. test cases added
5. exact test/build output
6. any unavailable/unsupported model-effort combinations discovered
7. blockers before Phase 3
