# Phase 3 — Pipelines, MCP Server, and Safe Cross-Provider Writing

## Objective

Turn the orchestrator into a practical tool that Claude Code, Codex, or another MCP-capable host can use as a shared multi-provider worker runtime.

At the end of this phase the project must support:

- MCP exposure of the router
- multi-stage pipelines
- independent review pipelines
- optional isolated write workers using Git worktrees
- explicit write ownership
- safe collection/integration metadata
- richer telemetry

The lead/caller still owns final integration and final decisions.

---

## Required prerequisite

Phases 1 and 2 must be complete and passing.

Do not weaken read-only defaults.

---

## MCP server

Create:

```text
packages/orchestrator/src/mcp.ts
```

Expose tools equivalent to:

```text
dtr_health
dtr_models
dtr_select
dtr_run
dtr_fanout
dtr_pipeline
dtr_status
```

Optional if implemented safely:

```text
dtr_abort
```

Requirements:

- use the official Model Context Protocol SDK
- validate all inputs with schemas
- do not expose environment variables/secrets
- do not allow arbitrary shell commands through MCP
- only expose router-level operations
- return run IDs for long/multi-worker operations
- support caller-provided working directory

Document installation in Claude Code and Codex without assuming one is always the lead.

Example architecture:

```text
Claude Code or Codex
        ↓
Dynamic Task Router MCP
   ├── Claude worker
   ├── Codex worker
   └── Ollama worker
```

The orchestrator must remain host-neutral.

---

## Pipeline strategy

Create:

```text
packages/orchestrator/src/strategies/pipeline.ts
```

Represent pipelines explicitly rather than encoding them in one giant prompt.

Suggested types:

```ts
export interface PipelineStage {
  id: string;
  role: WorkerRole;
  strategy: "single" | "fanout";
  readOnly: boolean;
  dependsOn?: string[];
  diversity?: DiversityLevel;
  preferredFamilies?: string[];
}

export interface PipelineDefinition {
  id: string;
  stages: PipelineStage[];
}
```

Workers should receive only stage-local context and required prior-stage evidence.

Do not expose full sibling transcripts unnecessarily.

---

## Initial pipeline templates

Implement configuration-driven templates for at least:

### `debug-review`

```text
1. primary debugger
2. independent debugger from another family
3. read-only reviewer
```

### `plan-challenge-review`

```text
1. architect creates plan
2. independent model challenges plan
3. architect or lead receives challenge evidence
4. final reviewer checks resulting proposal/diff
```

### `implement-review`

Initially:

```text
1. implementation worker in isolated worktree
2. tests/checks
3. independent read-only reviewer
4. caller decides whether to integrate
```

Do not auto-merge in Phase 3.

---

## Write access design

Cross-provider workers are still read-only by default.

Write access must require:

- explicit `write=true`
- a single declared write owner for each path boundary
- isolated Git worktree
- clean base repository state check
- explicit allowed path list
- no automatic merge
- verification commands
- returned diff metadata

Never allow two workers to write to the same shared checkout concurrently.

---

## Worktree manager

Create a dedicated module, for example:

```text
packages/orchestrator/src/worktrees/
├── manager.ts
└── types.ts
```

Requirements:

- create worktrees under `.dtr/worktrees/<run-id>/<worker-id>`
- create a unique branch per write worker
- verify target repo is a Git repository
- refuse unsafe dirty-state scenarios unless a documented safe mode exists
- clean up only worktrees created by DTR
- never delete user branches/worktrees
- never force reset the user's working tree

Returned worker result should include:

```json
{
  "branch": "dtr/run-123-worker-implementation",
  "worktree": ".dtr/worktrees/run-123/implementation",
  "changedPaths": ["src/foo.ts"],
  "checks": [
    {"command": "npm test", "success": true}
  ]
}
```

---

## Write-capable provider invocation

Extend provider adapters so write mode is an explicit separate code path.

### Claude

Use a permission mode that permits edits only inside the assigned worktree and according to the worker contract.

Do not reuse the read-only command blindly.

### Codex

Use workspace-write only inside the assigned worktree.

Never use danger-full-access for normal routed coding.

### Ollama

If local model write behavior is not reliable enough, keep Ollama read-only and mark `write_capable: false` in the model registry.

The registry, not hard-coded provider assumptions, should control eligibility.

---

## Path ownership

Add a write-boundary type:

```ts
export interface WriteBoundary {
  allowedPaths: string[];
  forbiddenPaths?: string[];
}
```

Before and after a write worker:

- record Git status
- verify resulting changed paths are within allowed paths
- if worker changed an out-of-scope path, mark run failed
- do not silently keep out-of-scope changes

Do not auto-delete evidence before reporting the failure.

---

## Review model selection

Reviewers must be fresh and read-only.

When possible:

- choose a different family from the implementation worker
- choose a model with high reviewer score
- use high effort for high-risk changes

Reviewer receives:

```text
request/objective
relevant diff
invariants
checks actually run
```

Reviewer must not receive fabricated claims that checks passed.

---

## Status/run registry

Implement in-memory + filesystem-backed run state sufficient for:

```text
queued
running
succeeded
failed
aborted
```

Persist under:

```text
.dtr/runs/
```

A process restart may degrade live process control, but historical run state must remain readable.

Do not claim a worker was aborted if the process could not actually be stopped.

---

## Telemetry expansion

Record:

- task profile
- provider/model/family
- requested/effective effort
- strategy
- stage
- read-only/write
- start/end/duration
- success/failure
- fallback used
- changed paths for writers
- checks and results
- reviewer outcome

Do not log secrets.

Make prompt/output logging optional and disabled by default.

---

## CLI

Add commands:

```text
dtr pipeline
dtr status
```

Optional:

```text
dtr abort
```

Examples:

```bash
dtr pipeline \
  --template debug-review \
  --risk high \
  --prompt "Trace why a valid signal fails before order submission"
```

```bash
dtr pipeline \
  --template implement-review \
  --write \
  --scope src/execution,tests/execution \
  --prompt "Fix the confirmed state-sync defect and add regression tests"
```

---

## MCP safety

The MCP surface must not allow a host model to bypass routing safety using arbitrary flags.

For example:

- no arbitrary `--sandbox danger-full-access`
- no arbitrary executable path
- no shell passthrough
- no arbitrary environment override

Expose strongly typed safe operations instead.

---

## Documentation

Add/update:

```text
docs/mcp.md
docs/pipelines.md
docs/worktrees.md
docs/safety.md
docs/architecture.md
```

Include installation examples for both:

```text
Claude Code lead → DTR MCP
Codex lead → DTR MCP
```

The docs must state that the project is not tied to either lead.

---

## Tests

Add tests for:

- MCP input validation
- pipeline dependency ordering
- pipeline failure propagation
- pipeline stage-local context
- worktree creation
- unique branches
- write-path boundary enforcement
- out-of-scope edit detection
- reviewer family diversity
- high-risk reviewer effort
- no auto-merge
- status persistence
- abort truthfulness

Add integration tests using a temporary Git repository.

Do not require live Claude/Codex calls for normal test suite.

---

## Acceptance criteria

Phase 3 is complete only when:

- all earlier tests still pass
- MCP server starts successfully
- Claude Code or Codex can invoke the router through MCP
- `dtr_pipeline` can run a multi-stage read-only pipeline
- optional write pipelines use isolated worktrees
- write workers cannot edit outside declared boundaries without detection
- no automatic merge occurs
- reviewer is fresh/read-only
- reviewer can be selected from an independent model family
- run/status metadata is persisted
- no arbitrary shell execution is exposed through MCP

---

## Do not implement yet

Do not add:

- OpenRouter
- Gemini
- dynamic remote model discovery
- automatic benchmark scraping
- autonomous routing-score mutation
- web dashboard
- automatic merge/deploy

---

## Final Codex report

Return:

1. changed files
2. MCP tools implemented
3. pipeline templates implemented
4. worktree safety behavior
5. exact test/build commands and results
6. any provider-specific write limitations
7. blockers before Phase 4
