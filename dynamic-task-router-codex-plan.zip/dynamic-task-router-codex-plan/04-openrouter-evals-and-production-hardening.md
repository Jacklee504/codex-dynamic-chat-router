# Phase 4 — OpenRouter, Evals, Cost/Privacy Routing, and Production Hardening

## Objective

Add the optional remote-model pool and the evidence needed to improve routing decisions over time without turning the router into an opaque self-modifying system.

At the end of this phase the project should support:

- OpenRouter as an optional provider
- model metadata and policy controls
- privacy-aware endpoint eligibility
- optional cost-aware routing
- routing evaluation datasets
- measured routing adjustments
- richer provider capability registry
- production-grade documentation and error handling

OpenRouter must remain optional. The router must work with only Claude/Codex/Ollama if configured that way.

---

## Required prerequisite

Phases 1–3 must be complete and passing.

Do not redesign core interfaces unless the current abstraction cannot represent a required capability.

---

## OpenRouter provider

Create:

```text
packages/orchestrator/src/providers/openrouter.ts
```

Use the OpenRouter API through a single optional API key.

Requirements:

- read key from environment/config reference, never repository files
- no hard-coded user key
- OpenRouter provider disabled by default when key is absent
- support explicit model IDs
- support tool-capability filtering where needed
- return standard `WorkerResult`
- capture provider/model metadata returned by OpenRouter when available

Do not use OpenRouter to proxy Claude/Codex subscription usage.

OpenRouter is a separate pay-as-you-go/free-tier provider.

---

## Provider capability metadata

Expand model registry support.

Each model may declare:

```yaml
capabilities:
  tools: true
  vision: false
  huge_context: true
  write_safe: false

limits:
  context_tokens: 1000000

cost:
  input_per_million: 0
  output_per_million: 0

privacy:
  private_code_allowed: false
  training_opt_out_required: true
```

Do not assume these values are permanent.

Document their source and update process.

---

## Privacy routing

Privacy must be an eligibility filter, not a score bonus.

Task profile should support:

```text
privacySensitive
privateCode
allowRemote
allowedFamilies
allowedProviders
```

If a model/provider is not approved for private code, it must be ineligible for private repository tasks.

Never fall back from a privacy-safe model to an unsafe provider silently.

---

## Free-model policy

Support OpenRouter free models, but do not treat `free` as equivalent to `safe` or `good`.

A free-model entry must still satisfy:

- context requirement
- tool requirement
- role capability
- privacy policy
- model-family diversity requirement

Prefer pinning explicit models for repeatable engineering evaluations.

Automatic free-router selection may be supported only as an explicitly configured fallback mode.

---

## Cost-aware routing

Add optional policy fields:

```yaml
budget:
  mode: ignore | prefer_free | capped
  max_estimated_cost_usd: 0.50
```

Cost must never override:

- safety
- privacy
- local-only requirements
- minimum capability

A cheaper but unsuitable model is not eligible.

Selection order should remain conceptually:

```text
eligibility
→ capability/role fit
→ safety/privacy/risk
→ diversity
→ cost preference
```

---

## Model discovery

Implement OpenRouter model discovery behind a cache.

Do not fetch the remote model catalog on every routed request.

Persist cached metadata with timestamp.

Allow:

```text
dtr models refresh
```

If discovery fails, use the last known cache and mark it stale.

Do not mutate manually configured model priors automatically during refresh.

---

## Evals

Create:

```text
evals/
├── cases/
├── fixtures/
├── expected/
└── README.md
```

Add a small representative routing benchmark.

Start with task classes such as:

```text
simple implementation
mechanical refactor
repo research
unit-test generation
complex debugging
architecture
read-only review
high-risk financial review
log analysis
local-only private task
large-context analysis
```

Each eval case should define expected routing properties rather than one permanently fixed model when possible.

Example:

```yaml
id: high-risk-review
role: reviewer
complexity: difficult
risk: high
diversity: medium
expect:
  minimum_effort: high
  independent_family: true
  read_only: true
  minimum_reviewer_score: 8
```

This prevents tests becoming stale when model inventory changes.

---

## Outcome telemetry

Expand telemetry so manually reviewed outcomes can be attached to runs.

Support fields such as:

```text
accepted
rejected
partial
escalated
review_findings_count
regression_detected
manual_score
```

Do not automatically retrain or rewrite routing policy from raw run logs.

Instead provide analysis tooling that suggests changes.

---

## Routing analysis command

Add something like:

```text
dtr evaluate
dtr stats
```

`dtr stats` should summarize results such as:

```text
role: test
model: codex-luna
accepted: 31/34
median duration: ...

role: complex-debug
model: qwen-local
escalated: 8/10
```

Do not claim causal superiority from tiny samples.

Add minimum sample thresholds before suggesting routing-prior changes.

---

## Priors update workflow

Implement a human-reviewed workflow.

Preferred pattern:

```text
run telemetry
→ aggregate stats
→ generate suggested config changes
→ human/Codex review
→ explicit config edit
```

Do not implement autonomous self-modification of `models.yaml`.

---

## Optional Google/Gemini adapter

Only implement if it fits cleanly after OpenRouter and the provider abstraction.

If implemented, place in:

```text
packages/orchestrator/src/providers/gemini.ts
```

It must be optional and must not block Phase 4 completion if authentication/harness integration is not sufficiently stable.

The main value would be:

- different model family
- huge context
- multimodal/browser-oriented workflows

Do not add it just to increase provider count.

---

## Production hardening

Review the entire orchestrator for:

- process timeouts
- cancellation
- child-process cleanup
- malformed CLI output
- provider rate limits
- provider authentication expiry
- model not found
- Ollama server unavailable
- model unloaded mid-run
- stale model registry
- disk cleanup for `.dtr/worktrees`
- telemetry corruption
- concurrent run collisions
- path traversal
- unsafe repo paths
- secret redaction

Add explicit error classes where useful.

---

## Security constraints

The orchestrator must never:

- expose stored API keys through MCP/CLI output
- write secrets into telemetry
- send private code to disallowed remote providers
- bypass worktree boundaries
- auto-merge or auto-deploy
- execute arbitrary shell supplied through MCP
- claim a provider/model was used when a fallback actually ran

---

## Documentation overhaul

Update the root README so the project is described as:

> A provider-agnostic multi-model engineering orchestrator with optional host-specific skills/plugins.

Document the architecture:

```text
Host/lead
  ↓
DTR orchestration engine
  ├── Claude adapter
  ├── Codex adapter
  ├── Ollama adapter
  ├── OpenRouter adapter
  └── optional future providers
```

Add/update:

```text
docs/architecture.md
docs/providers.md
docs/adding-a-provider.md
docs/model-selection.md
docs/reasoning-levels.md
docs/privacy.md
docs/cost-routing.md
docs/evals.md
docs/mcp.md
docs/troubleshooting.md
```

Preserve existing host-specific installation docs where still relevant.

---

## Adding a provider guide

`docs/adding-a-provider.md` must explain the minimum contract:

```ts
interface Provider {
  id: ProviderId;
  health(): Promise<boolean>;
  run(request: WorkerRequest): Promise<WorkerResult>;
}
```

and required concerns:

- authentication
- read-only mode
- optional write capability
- reasoning effort mapping
- model-family identity
- capability metadata
- privacy policy
- cancellation
- telemetry
- tests

The goal is that future providers do not require router-core rewrites.

---

## Tests

Add tests for:

- OpenRouter disabled without key
- explicit OpenRouter model invocation mock
- privacy filtering
- free-model eligibility
- cost caps
- stale metadata cache
- model catalog refresh failure
- eval runner
- stats aggregation
- minimum sample threshold
- no autonomous config mutation
- secret redaction
- concurrency/run-ID collision safety
- path traversal protection

All paid-provider tests must be mocked by default.

---

## Acceptance criteria

Phase 4 is complete only when:

- all previous tests still pass
- OpenRouter is optional and cleanly disabled without credentials
- OpenRouter models participate in normal eligibility/selection rules
- privacy restrictions are enforced before scoring
- optional cost routing works without overriding safety/capability
- eval cases are version-controlled
- routing stats can be generated from telemetry
- routing-prior changes remain human-reviewed
- provider metadata can be refreshed/cached safely
- docs clearly explain how to add future providers
- the repo still works with only Claude/Codex/Ollama enabled

---

## Final project definition of done

The repository should now be a real multi-provider engineering router rather than a collection of parallel skills.

A caller should be able to request work and have DTR determine:

```text
provider
model
reasoning effort
execution strategy
model-family diversity
local/remote eligibility
privacy eligibility
cost preference
```

while preserving:

```text
one lead owns the objective
bounded workers
explicit write ownership
fresh independent review
observable evidence
truthful handoff/status
```

---

## Final Codex report

Return:

1. changed files
2. providers supported
3. routing/eval features implemented
4. privacy/cost behavior
5. exact build/test commands and results
6. any remaining known limitations
7. suggested next releases, but do not implement them unless separately requested
