# Phase 1 — Executable Orchestrator Foundation

## Objective

Convert `dynamic-task-router` from primarily a host-skill/adaptor repository into a small executable TypeScript monorepo while preserving the existing host-specific packages.

At the end of this phase the repository must have a working `packages/orchestrator` package that can invoke:

- Claude Code through the authenticated `claude` CLI
- Codex through the authenticated `codex` CLI
- Local Ollama models through Codex OSS mode

All cross-provider workers must be **read-only** in this phase.

Do not remove or rewrite the existing Claude, Codex, or Qwen packages unless a minimal compatibility edit is required.

---

## Existing architecture to preserve

The repository currently treats `core/` as the source of truth for routing behavior and keeps host-specific adapters under:

```text
packages/claude/
packages/codex/
packages/qwen/
```

Preserve that structure.

Add a new executable package:

```text
packages/orchestrator/
```

The new orchestrator is the provider-agnostic runtime. Existing packages remain compatibility adapters/plugins.

---

## Target repository structure

Create or update the repository to resemble:

```text
dynamic-task-router/
├── core/
│   ├── routing-contract.md
│   ├── model-selection.md
│   ├── task-taxonomy.md
│   ├── safety-policy.md
│   └── acceptance-scenarios.md
├── config/
│   ├── models.yaml
│   └── routing-policy.yaml
├── packages/
│   ├── orchestrator/
│   │   ├── package.json
│   │   ├── tsconfig.json
│   │   ├── src/
│   │   │   ├── cli.ts
│   │   │   ├── types.ts
│   │   │   ├── config.ts
│   │   │   ├── providers/
│   │   │   │   ├── claude.ts
│   │   │   │   ├── codex.ts
│   │   │   │   └── ollama.ts
│   │   │   └── telemetry/
│   │   │       └── run-log.ts
│   │   └── tests/
│   ├── claude/
│   ├── codex/
│   └── qwen/
├── docs/
├── package.json
├── tsconfig.base.json
└── README.md
```

Do not create empty placeholder files that are not used in this phase.

---

## Root workspace

Add a root `package.json` suitable for npm workspaces.

Requirements:

- Node >= 20
- ESM
- workspace includes `packages/orchestrator`
- scripts for build, test, and running the router

Suggested shape:

```json
{
  "name": "dynamic-task-router",
  "private": true,
  "type": "module",
  "workspaces": [
    "packages/orchestrator"
  ],
  "scripts": {
    "build": "npm run build --workspace @dynamic-task-router/orchestrator",
    "test": "npm run test --workspace @dynamic-task-router/orchestrator",
    "dtr": "npm run dtr --workspace @dynamic-task-router/orchestrator"
  },
  "engines": {
    "node": ">=20"
  }
}
```

Add `tsconfig.base.json` with strict TypeScript settings.

---

## Orchestrator package

Create `packages/orchestrator/package.json`.

Use:

- TypeScript
- `tsx` for development execution
- `vitest` for tests
- `yaml` for configuration
- `zod` for config validation

Use current compatible package versions rather than blindly pinning versions from this document.

Add scripts:

```text
build
dtr
test
```

---

## Core provider interface

Create `packages/orchestrator/src/types.ts`.

The orchestrator must use one provider-neutral interface.

Use a design equivalent to:

```ts
export type ProviderId = "claude" | "codex" | "ollama" | "openrouter";

export type Effort = "low" | "medium" | "high" | "xhigh" | "max";

export type WorkerRole =
  | "architect"
  | "implementer"
  | "debugger"
  | "reviewer"
  | "researcher"
  | "test"
  | "log-analysis";

export interface WorkerRequest {
  prompt: string;
  cwd: string;
  role: WorkerRole;
  model: string;
  effort: Effort;
  readOnly: boolean;
}

export interface WorkerResult {
  provider: ProviderId;
  model: string;
  requestedEffort: Effort;
  effectiveEffort?: string;
  output: string;
  success: boolean;
  durationMs: number;
}

export interface Provider {
  id: ProviderId;
  health(): Promise<boolean>;
  run(request: WorkerRequest): Promise<WorkerResult>;
}
```

Exact type names may differ if there is a clear reason, but preserve the abstraction.

---

## Claude provider

Implement `src/providers/claude.ts`.

Invoke the installed/authenticated Claude Code CLI non-interactively.

Requirements:

- no API key handling in this project
- use the user's existing Claude Code authentication
- invoke workers read-only
- prevent recursive loading of this router where possible
- capture stdout/stderr
- enforce timeout/abort support at process level
- return structured `WorkerResult`

Preferred command shape:

```bash
claude \
  --bare \
  -p "$PROMPT" \
  --model "$MODEL" \
  --effort "$EFFORT" \
  --output-format json \
  --permission-mode plan \
  --no-session-persistence
```

Do not assume every effort level is supported by every Claude model. Validate/mapping belongs in configuration.

If `claude` is unavailable, `health()` must return false rather than throwing an opaque error.

---

## Codex provider

Implement `src/providers/codex.ts`.

Use the installed/authenticated Codex CLI and the user's existing ChatGPT subscription authentication.

Requirements:

- no OpenAI API key handling
- read-only sandbox
- no approval prompts for read-only workers
- ephemeral execution
- isolate from user config where necessary to prevent recursion
- capture stdout/stderr
- return structured `WorkerResult`

Preferred command shape:

```bash
codex exec \
  --cd "$CWD" \
  --model "$MODEL" \
  --sandbox read-only \
  --ask-for-approval never \
  --ephemeral \
  --ignore-user-config \
  -c "model_reasoning_effort=$EFFORT" \
  "$PROMPT"
```

If an option is unsupported by the installed Codex version, detect that explicitly and implement a documented fallback instead of silently dropping safety constraints.

---

## Ollama provider

Implement `src/providers/ollama.ts` using Codex OSS mode as the first implementation.

The goal is to let local models use a coding-agent harness while inference runs through Ollama.

Preferred shape:

```bash
codex exec \
  --oss \
  --local-provider ollama \
  --model "$MODEL" \
  --cd "$CWD" \
  --sandbox read-only \
  --ask-for-approval never \
  --ephemeral \
  --ignore-user-config \
  "$PROMPT"
```

Requirements:

- detect whether Ollama is reachable
- detect whether the requested model is installed
- do not automatically pull models in Phase 1
- return a useful error if model/server is unavailable
- never use paid Codex inference for an Ollama-routed task

Do not require OpenCode.

---

## Configuration

Create `config/models.yaml` and `config/routing-policy.yaml`.

For Phase 1, configuration only needs to support:

- provider
- family
- model ID
- enabled
- local
- allowed roles
- allowed effort values
- default effort

Initial model entries should include the locally/externally available models but must be easy to edit.

Do not hard-code the user's exact model inventory in source code.

Example model names may include:

```text
claude-opus
claude-sonnet
codex-sol
codex-luna
codex-terra
qwen-local
gpt-oss-local
```

Treat capability scores as routing priors, not benchmark facts.

---

## CLI

Create a minimal `src/cli.ts`.

Phase 1 commands:

```text
dtr health
dtr models
dtr run
```

Suggested behavior:

### `dtr health`

Report availability of:

- Claude CLI/auth
- Codex CLI/auth
- Ollama server
- configured Ollama models

Do not expose secrets.

### `dtr models`

Print configured models and availability.

### `dtr run`

Allow explicit invocation only in Phase 1:

```bash
dtr run \
  --provider codex \
  --model gpt-5.6-terra \
  --effort high \
  --role reviewer \
  --cwd /path/to/repo \
  --prompt "Review the execution pipeline. Do not modify anything."
```

Automatic model selection comes in Phase 2.

---

## Telemetry

Create `.dtr/runs/` at runtime and add `.dtr/` to `.gitignore`.

Record one JSON file per run.

Minimum fields:

```json
{
  "provider": "codex",
  "model": "gpt-5.6-terra",
  "role": "reviewer",
  "requestedEffort": "high",
  "effectiveEffort": "high",
  "readOnly": true,
  "success": true,
  "durationMs": 12345,
  "timestamp": "ISO-8601"
}
```

Do not store full prompts or model outputs by default in Phase 1. Add optional verbose logging later.

---

## Routing contract changes

Update `core/routing-contract.md` without weakening current invariants.

Add rules equivalent to:

1. Provider, model, and effort are orchestration metadata and are not placed in worker prompts unless execution requires it.
2. Record requested/effective provider, model, and effort for every worker.
3. Cross-provider workers are read-only by default.
4. Parallel writers require isolated worktrees and explicit write ownership.
5. High-diversity tasks must use independent model families.
6. Model selection is based on declared routing policy and measured outcomes, not a global ranking.
7. Provider/model/effort fallback must be explicit and logged.

Keep the existing compact worker task contract:

```text
GOAL: <observable outcome>
SCOPE: <allowed paths>
DO NOT: <non-goals>
CHECK: <commands or evidence>
RETURN: changed paths; check result; blocker/risk
```

Do not inject provider/model rationale into worker prompts.

---

## Tests

Add unit tests for:

- config parsing/validation
- provider health behavior when CLI is absent
- command construction for Claude
- command construction for Codex
- command construction for Ollama
- run logging
- read-only enforcement

Use process execution abstraction/injection so unit tests do not actually call paid services.

Add at least one optional integration test command that can be run manually when local CLIs are authenticated.

---

## Acceptance criteria

Phase 1 is complete only when all are true:

- `npm install` succeeds from repo root
- `npm run build` succeeds
- `npm test` succeeds
- existing host-specific packages remain present
- `dtr health` reports provider availability without exposing secrets
- `dtr models` shows configured models
- `dtr run` can explicitly invoke Claude, Codex, or local Ollama where available
- every worker is read-only
- provider/model/effort metadata is logged
- unavailable providers fail clearly
- no API keys are required for Claude/Codex subscription usage
- Ollama invocation does not route through paid inference

---

## Do not implement yet

Do not implement these in Phase 1:

- automatic model selection
- multi-provider fanout
- pipelines
- OpenRouter
- Gemini
- autonomous score learning
- cross-provider writing
- worktree integration
- web UI
- database

Keep Phase 1 small and reliable.

---

## Final Codex report

When complete, return:

1. changed files
2. architecture summary
3. exact test/build commands run
4. their results
5. any provider CLI compatibility issues found
6. remaining blockers before Phase 2
